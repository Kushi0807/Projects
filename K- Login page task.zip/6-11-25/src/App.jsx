import React, { useState } from "react";
import LoginPage from './LoginPage';

function App() {
  const [open, setOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setOpen(true);
    setUsername('');
    setPassword('');
  };

  return (
    <div style={{ textAlign: "center", marginTop: '100px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Login Page</h2>

      <form onSubmit={handleSubmit} autoComplete='off'>
        <div style={{ margin: '10px 0' }}>
          <label>Username:</label>
          <input
            type='text'
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            style={{ marginLeft: '10px', padding: '5px', borderRadius: '5px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ margin: '10px 0' }}>
          <label>Password:</label>
          <input
            type='password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ marginLeft: '10px', padding: '5px', borderRadius: '5px', border: '1px solid #ccc' }}
          />
        </div>

        <button
          type="submit"
          style={{ backgroundColor: 'skyblue', padding: '7px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
        >
          Submit
        </button>
      </form>

      {open && (
        <LoginPage>
          <h3 style={{ marginBottom: '20px', color: 'green' }}>Login Successful!</h3>
          <button
            onClick={() => setOpen(false)}
            style={{ backgroundColor: '#555', color: 'white', padding: '7px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
          >
            Close
          </button>
        </LoginPage>
      )}
    </div>
  );
}

export default App;
